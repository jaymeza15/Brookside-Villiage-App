<?php
	if (isset($_POST["app-sub"])) {
		require '../DatabaseConn.php';

		$theID = $_POST["tID"];
		$plan = $_POST["planDate"];
		$date = date("Y-m-d");

		if(empty($theID)){
			echo "WHY";
		}
		if (empty($plan)) {
			header("Location: ../Tasks_View.php?error=date");
			exit();
		}
		else if ($plan < $date) {
			header("Location: ../Tasks_View.php?error=olddate");
			exit();
		}

		$sql = "SELECT * FROM tasks WHERE taskID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE tasks 
				     SET status = '1', 
				     	 planDate = '$plan'
				     WHERE taskID = '$theID' ";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Tasks_View.php?error=sqlerror");}
			else {	header("Location: ../Tasks_View.php?success=approved");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
		

	}
	else if (isset($_POST["dec-sub"])) {
		require '../DatabaseConn.php';
		
		$theID = $_POST["tID"];

		$sql = "SELECT * FROM tasks WHERE taskID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE tasks 
				     SET status = '3'
				     WHERE taskID = '$theID' ";

		if (!mysqli_query($conn, $sql2)) {	header("Location: ../Tasks_View.php?error=sqlerror");}
			else {	header("Location: ../Tasks_View.php?success=declined");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
	}
	if (isset($_POST["comp-sub"])) {
		require '../DatabaseConn.php';

		$theID = $_POST["tID"];
		$comp = date("Y-m-d");

		$sql = "SELECT * FROM tasks WHERE taskID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE tasks 
				     SET status = '2', 
				     	 compDate = '$comp'
				     WHERE taskID = '$theID' ";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Tasks_View.php?error=sqlerror");}
			else {	header("Location: ../Tasks_View.php?success=completed");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
		

	}
	else{
		echo "error";
	}
?>