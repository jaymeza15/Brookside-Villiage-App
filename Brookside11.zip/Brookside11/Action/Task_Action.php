<?php
	if(isset($_POST["task-submit"])){
		require '../DatabaseConn.php';

		session_start();
		//Session variables
		$theID = $_SESSION["ID"];
		$full = $_SESSION["first"]. " " . $_SESSION["last"];
		//Post variables
		$type = $_POST["type"];
		$sub = $_POST["subject"];
		$pri = $_POST["priority"];
		$des = $_POST["description"];
		$date = date("Y-m-d h:i:s");

		$sql = " SELECT * FROM tasks WHERE creatorID = '$theID' AND type = '$type' ";
		$result = mysqli_query($conn,$sql);
		$count = mysqli_num_rows($result);

		if ($count >= 6) {
			header("Location: Tasks_View.php?error=TooMany");
			exit();
		}

		$sql2 = "INSERT INTO tasks    (creatorID,
								   	   fullName,
								       priority,
								       type,
								       subject,
								       description,
								       status,
								       submitDate) 
						       VALUES ('$theID',
						   	           '$full',
						   	           '$pri',
						   	           '$type',
						   	           '$sub',
						   	           '$des',
						   	           '0',
						   	       	   '$date')";

		if (!mysqli_query($conn, $sql2)) {	header("Location: ../Tasks_View.php?error=sqlerror");}
		else {	header("Location: ../Home1.php?success=insert");}
	}
?>