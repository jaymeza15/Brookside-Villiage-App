<?php
	if(isset($_POST["login-submit"])){
		require '../DatabaseConn.php';

		$username = $_POST["username"];
		$password = $_POST["password"];


		if(empty($username) || empty($password)){
			header("Location: ../Index.php?error=emptyfields");
			exit();
		}

		$sql = "SELECT * FROM users WHERE username = '$username' ";
		$stmt = mysqli_stmt_init($conn);
		$result = mysqli_query($conn, $sql);
		
		if(!mysqli_stmt_prepare($stmt, $sql)){
			header("Location: Index.php?error=sqlerror");
			exit();
		}

		if ($row = mysqli_fetch_assoc($result)) {
			
			if($password != $row["password"]){
				header("Location: Index.php?error=userORpass");
				exit();
			}

			session_start();
			$theID = $row["userID"];
			$_SESSION["ID"] = $row["userID"];
			$_SESSION["uname"] = $row["username"];
			$_SESSION["pwd"] = $row["password"];
			$_SESSION["utype"] = $row["usertype"];
			$_SESSION["first"] = $row["firstname"];
			$_SESSION["last"] = $row["lastname"];
			$_SESSION["bd"] = $row["birthday"];
			$_SESSION["rm"] = $row["room"];


			if ($theID[0] == 1) {	header("Location: ../Home1.php"); }
			else 				{	header("Location: ../Home2.php"); }
		}



	}
	else{
		echo "Submittion ERROR!!!!";
	}






?>