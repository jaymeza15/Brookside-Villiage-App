<?php
	require('../DatabaseConn.php');

	if (isset($_POST['user-submit'])) {
		$usertype = $_POST['usertype'];
		$per =      $_POST['permission'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$pass2 =    $_POST['pass2'];
		$first =    $_POST['firstname'];
		$last =     $_POST['lastname'];
		$bday =     $_POST['bday'];
		$rm =       $_POST['room'];


		if (empty($usertype) || empty($username) || empty($username) || empty($password) || empty($pass2) || empty($first) || empty($last) || empty($bday) || empty($rm) ){

			header("Location: ../UserAdd_View.php?error=emptyfields");
			exit();
		}

		if($usertype != 'Tenant'){
			if($per != 12345678){
				header("Location: ../UserAdd_View.php?error=permissions");
				exit();
			}
		}

		$sql = "SELECT * FROM users WHERE username = '$username' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if ($count == 1) {
			header("Location: ../UserAdd_View.php?error=username");
			exit();
		}
		

		if ($password != $pass2) {
			header("Location: ../UserAdd_View.php?error=passwordconfirm");
			exit();
		}
		else{
			if (strlen($password) < 6 || !preg_match("#[0-9]+#", $password) || !preg_match("#[A-Z]+#", $password) ) {
				header("Location: ../UserAdd_View.php?error=passwordrequirements");
				exit();
			}
		}

		$sql = "SELECT * FROM users WHERE room = '$rm' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if ($count == 1) {
			header("Location: ../UserAdd_View.php?error=room");
			exit();
		}


		$fd = 0;
		$rest = rand(0,9999999);

		     if($usertype == "Tenant")   {	$fd = 1;}
		else if($usertype == "Manager")  {	$fd = 2;}
		else if($usertype == "Board")	 {	$fd = 3;}

		$theID = $fd.$rest;
		$sql2 = "SELECT * FROM users WHERE userID = '$theID' ";
		$result2 = mysqli_query($conn, $sql2);
		$count2 = mysqli_num_rows($result2);

		if($count2 == 1){
			$rest = rand(0,9999999);
			$theID = $fd.$rest;
		}

		$sql3 = "INSERT INTO users (userID,
								   username,
								   password,
								   usertype,
								   firstname,
								   lastname,
								   birthday,
								   room)
							VALUES('$theID',
								   '$username',
								   '$password',
								   '$usertype', 
								   '$first',
								   '$last',
								   '$bday',
								   '$rm') ";

		if( !mysqli_query($conn, $sql3) ){
			header("Location: ../UserAdd_View.php?error=sqlerror");
			exit();
		}
		else{
			header("Location: ../Index.php");
		}





	}
	else{
		echo "error submittion";
	}








?>