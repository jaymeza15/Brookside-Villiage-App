<?php
	if (isset($_POST["app-sub"])) {
		require '../DatabaseConn.php';

		$theID = $_POST["tID"];

		if(empty($theID)){
			echo "WHY ID empty";
		}

		$sql = "SELECT * FROM requests WHERE requestID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE requests 
				        SET status = '1'
				      WHERE requestID = '$theID' ";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Requests_View.php?error=sqlerror");}
			else {	header("Location: ../Requests_View.php?success=approved");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
		

	}
	else if (isset($_POST["dec-sub"])) {
		require '../DatabaseConn.php';

		$theID = $_POST["tID"];
		$comp = date("Y-m-d");

		$sql = "SELECT * FROM requests WHERE requestID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE requests
				        SET status = '3', 
				     	    compDate = '$comp'
				      WHERE requestID = '$theID' ";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Requests_View.php?error=sqlerror");}
			else {	header("Location: ../Requests_View.php?success=decline");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
		

	}
	else if (isset($_POST["comp-sub"])) {
		require '../DatabaseConn.php';

		$theID = $_POST["tID"];
		$comp = date("Y-m-d");

		$sql = "SELECT * FROM requests WHERE requestID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE requests
				        SET status = '2', 
				     	    compDate = '$comp'
				      WHERE requestID = '$theID' ";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Requests_View.php?error=sqlerror");}
			else {	header("Location: ../Requests_View.php?success=completed");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
		

	}
	?>