<?php
	if (isset($_POST["complaint-submit"])) {
		require '../DatabaseConn.php';

		session_start();
		$theID = $_SESSION["ID"];
		$full = $_SESSION["first"] . " " . $_SESSION["last"];
		$type = $_POST["type"];
		$sub = $_POST["subject"];
		$des = $_POST["description"];
		$date = date("Y-m-d h:i:s");

		$sql = "SELECT * FROM complaints WHERE creatorID = '$theID' AND type = '$type' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count > 3){
			header("Location: ../Complaints_View.php?error=TooMany");
			exit();
		}
		else {
			
			$sql2 = "INSERT INTO complaints (senderID,
											sender,
											type,
											subject,
											description,
											status,
											submitDate)
									VALUES ('$theID',
											'$full',
											'$type',
											'$sub',
											'$des',
											  '0',
											'$date')";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Complaints_View.php?error=sqlerror");}
			else {	header("Location: ../Home1.php?success=insert");}
		}
	}
?>