<?php
	if (isset($_POST["app-sub"])) {
		require '../DatabaseConn.php';

		$theID = $_POST["tID"];

		if(empty($theID)){
			echo "WHY ID empty";
		}

		$sql = "SELECT * FROM complaints WHERE complaintID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE complaints 
				        SET status = '1'
				      WHERE complaintID = '$theID' ";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Complaints_View.php?error=sqlerror");}
			else {	header("Location: ../Complaints_View.php?success=approved");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
		

	}
	else if (isset($_POST["comp-sub"])) {
		require '../DatabaseConn.php';

		$theID = $_POST["tID"];

		if(empty($theID)){
			echo "WHY ID empty";
		}

		$sql = "SELECT * FROM complaints WHERE complaintID = '$theID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count == 1){
			$sql2 = "UPDATE complaints 
				        SET status = '2'
				      WHERE complaintID = '$theID' ";

			if (!mysqli_query($conn, $sql2)) {	header("Location: ../Complaints_View.php?error=sqlerror");}
			else {	header("Location: ../Complaints_View.php?success=completed");}
		}
		else {
			header("Location: ../Home2.php?error=sqlerror2");
			exit();
		}
		

	}
	?>