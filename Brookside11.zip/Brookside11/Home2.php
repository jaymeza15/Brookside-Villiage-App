<?php
	session_start();
	require 'Header1.php';
	require 'Display/Welcome.php';
?>