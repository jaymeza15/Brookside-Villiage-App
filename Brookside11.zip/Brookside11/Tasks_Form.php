<?php
	require 'DatabaseConn.php';
	session_start();
	$idnum = $_SESSION["ID"];
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Tasks Form</title>
		<link rel="stylesheet" type="text/css" href="CSS/TheBestCss4.css">
		<link rel="stylesheet" type="text/css" href="CSS/Elements.css">
		<script type="text/javascript" src="JS/Tasks.js"></script>
		<meta charset="utf-8">
	</head>
	<body>
		<?php
		if ($idnum[0] == 1){
			require 'Header1.php';	
			require 'Display/taskform.php';
		}
		else{
			require 'Header2.php';
			require 'Display/taskform.php';
		}
			
		?>
		<br>

		<?php
			require 'Display/footer.html';
		?>	



	</body>
</html>