<h3 align="center"> Complaint Page </h3>
<div id="taskheader" align="center">
	<?php
		if(isset($_GET['success'])){
			if ($_GET['success'] == "insert") {
				echo '<p class="error"> Successfully submitted the Complaint </p>';
			}
			else if ($_GET['success'] == "declined") {
				echo '<p class="error"> Successfully declined the Complaint</p>';
			}
			else if ($_GET['success'] == "completed") {
				echo '<p class="error"> Successfully completed the Complaint </p>';
			}
		}
		if(isset($_GET['error'])){
			if ($_GET['error'] == "sqlerror") {
				echo '<p class="error"> Error: Please contact administrator </p>';
			}
			else if ($_GET['error'] == "pending") {
				echo '<p class="error"> Error(Pending): Please contact administrator </p>';
			}
		}
	?>
	<table align="center"> 
		<tr> 
			<button onclick="Appear(1)" id="B1" class="btn"> File A Complaint </button>
			<button onclick="Appear(2)" id="B2" class="btn"> Pending 	   </button>
			<button onclick="Appear(3)" id="B3" class="btn"> Reviewed	   </button>
			<button onclick="Appear(4)" id="B4" class="btn"> Completed     </button>
			<button onclick="Appear(5)" id="B5" class="btn"> Search        </button>
		</tr>
	</table>
</div>
<div id="createDiv" style="display: none;" align="center">
	<br><br>
	Lets Create A Complaint
	<form action="Action/Complaint_Action.php" method="post">
		<br>
		<select class="select-css" name="type">
			<option> </option>
			<option value="Heating">     Heating     </option>
			<option value="Cooling">     Cooling     </option>
			<option value="Repair">      Repair      </option>
			<option value="Plumbing">    Plumbing    </option>
			<option value="Painting">    Painting    </option>
			<option value="Electric"> 	 Electric    </option>
			<option value="Locks">       Locks       </option>
			<option value="Replacement"> Replacement </option>
			<option value="Tasks">       Tasks       </option>
			<option value="Requests">    Requests    </option>
			<option value="Other">       Other       </option>
		</select>
		<br>
		<input type="text" name="subject" placeholder="Subject">
		<br><br>
		<input type="textarea" name="description" placeholder="Description" style="height: 200px; width: 200px; align-content: center;">
		<br><br>
		<input type="submit" name="complaint-submit" value="Submit">
	</form>
</div>
<div id="pDiv" style="display: none;">
	<h2> Submitted Complaints: </h2>
	<br>
	<?php
		//require 'Display/pendingTasks.php';
		require 'Display/pendingComplaints.php';

	?>
</div>
<div id="aDiv" style="display: none;">
	<h2> Reviewed Complaints: </h2>
	<br>
	<?php
		require 'Display/approvedComplaints.php';
	?>
</div>
<div id="cDiv" style="display: none;">
	<h2> Completed Complaints: </h2>
	<br>
	<?php
		require 'Display/completedComplaints.php';
	?>
</div>
<div id="sDiv" style="display: none;">
	<h2> Search Complaints: </h2>
	<br>
	<?php
		require 'Display/searchComplaints.php';
	?>
</div>