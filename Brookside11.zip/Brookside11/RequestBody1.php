<center><h3 align="center"> Request Page </h3></center>
<div id="taskheader" align="center">
	<?php
		if(isset($_GET['success'])){
			if ($_GET['success'] == "insert") {
				echo '<p class="error"> Successfully submitted the Request </p>';
			}
			else if ($_GET['success'] == "completed") {
				echo '<p class="error"> Successfully completed the Request </p>';
			}
			
		}
		if(isset($_GET['error'])){
			if ($_GET['error'] == "sqlerror") {
				echo '<p class="error"> Error: Please contact administrator </p>';
			}
			if ($_GET['error'] == "pending") {
				echo '<p class="error"> Error(Pending): Please contact administrator </p>';
			}
		}

	?>
	<table align="center"> 
		<tr> 
			<button onclick="Appear(1)" id="B1" class="btn"> Create A Request </button>
			<button onclick="Appear(2)" id="B2" class="btn"> Pending 	   </button>
			<button onclick="Appear(3)" id="B3" class="btn"> Approved	   </button>
			<button onclick="Appear(4)" id="B4" class="btn"> Completed     </button>
			<button onclick="Appear(5)" id="B5" class="btn"> Search        </button>
		</tr>
	</table>
</div>
<div id="createDiv" style="display: none;" align="center">
	Lets Create A Request:
	<form action="Action/Request_Action.php" method="post">
		<select class="select-css" name="type">
			<option> </option>
			<option value="Flooring">    Flooring     </option>
			<option value="Painting">    Painting     </option>
			<option value="Renovation">  Renovation     </option>
			<option value="Appliance">   Appliance    </option>
			<option value="Electric"> 	 Electric    </option>
			<option value="Other">       Other       </option>
		</select>
		<br>
		<input type="text" name="subject" placeholder="Subject">
		<br>
		<input type="number" name="priority" placeholder="Priority">
		<br>
		<input type="text" name="description" placeholder="Description">
		<br>
		<input type="submit" name="request-submit" value="Submit">
	</form>
</div>

<div id="pDiv" style="display: none;">
	<h2> Pending Requests: </h2>
	<br>
	<?php
		require 'Display/pendingRequests.php';
	?>
</div>

<div id="aDiv" style="display: none;">
	<h2> Accepted Requests: </h2>
	<br>
	<?php
		require 'Display/approvedRequests.php';
	?>
</div>

<div id="cDiv" style="display: none;">
	<h2> Completed Requests: </h2>
	<br>
	<?php
		require 'Display/completedRequests.php';
	?>
</div>

<div id="sDiv" style="display: none;">
	<h2> Search Requests</h2>
	<br>
	<?php
		require 'Display/searchRequests.php';
	?>
</div>






