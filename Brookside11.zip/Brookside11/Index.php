<!DOCTYPE html>
<html>
	<head>
		<title> Login Page </title>
		<link rel="stylesheet" type="text/css" href="CSS/template.css">
	</head>
	<body>
		<h1> Welcome to the Brookside Village Application</h1>
		<p> </p>
		<h2> Please Login Below </h2>
		<p> </p>
		<div class="enjoy-css">
			<?php
				if(isset($_GET['error']))
				{
					if ($_GET['error'] == "emptyfields") {
						echo '<p class="error"> One or More of the fields are empty </p>';
					}
					else if ($_GET['error'] == "userORpass") {
						echo '<p class="error"> Username/password Match does not work </p>';	
					}
					else if ($_GET['error'] == "sqlerror") {
						echo '<p class="error"> There was an SQL error, Please contact the adminstrator </p>';
					}
				}
			?>

			<form action="Action/Login_Action.php" method="post">
				<input type="text" 	   name="username" placeholder="Username" size="35">
				<input type="password" name="password" placeholder="Password">
				<button type="submit"  name="login-submit"> Login </button>
			</form>
			<br>
			<a href="UserAdd_View.php"> Create Account </a>
		</div>
	</body>
</html>