<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Json and Ajax</title>
	<link rel="stylesheet" type="text/css">
</head>
<body>
	<header>
		<h1> Json and Ajax</h1>
		<button id="btn"> Fetch info for 3 new animals </button>
	</header>

	<div id="animal-info"></div>

	<script src="js/main.js"></script>
	<body>
		

	</body>
</body>
</html>