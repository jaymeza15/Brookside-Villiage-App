function UserType(){
	var code = document.getElementById("per");
	var x = document.getElementById("theSelect").value;
	var y = document.getElementById("ut");
	
	if(x == "Tenant"){
		y.value = "Tenant";
		document.getElementById("per").style = "display: none;";
	}
	else if(x == "Manager"){
		y.value = "Manager";
		document.getElementById("per").style = "display: visible;";
	}
	else if(x == "Board"){
		y.value = "Tenant";
		document.getElementById("per").style = "display: visible;";
	}
	else
	{
		y.value = "";
		document.getElementById("per").style = "display: none;";
	}
}