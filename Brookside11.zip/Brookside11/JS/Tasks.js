function Appear(i)
{
	var b1 = document.getElementById("B1");
	var b2 = document.getElementById("B2");
	var b3 = document.getElementById("B3");
	var b4 = document.getElementById("B4");
	var b5 = document.getElementById("B5");
	
	var x1 = document.getElementById("createDiv");
	var x2 = document.getElementById("pDiv");
	var x3 = document.getElementById("aDiv");
	var x4 = document.getElementById("cDiv");
	var x5 = document.getElementById("sDiv");

	if (i == 1){
		b1.style.backgroundColor = "green";
		b2.style.backgroundColor = "white";
		b3.style.backgroundColor = "white";
		b4.style.backgroundColor = "white";
		b5.style.backgroundColor = "white";

		x1.style.display = 'block';
		x2.style.display = 'none';
		x3.style.display = 'none';
		x4.style.display = 'none';
		x5.style.display = 'none';
	}
	else if (i == 2){
		b1.style.backgroundColor = "white";
		b2.style.backgroundColor = "green";
		b3.style.backgroundColor = "white";
		b4.style.backgroundColor = "white";
		b5.style.backgroundColor = "white";

		x1.style.display = 'none';
		x2.style.display = 'block';
		x3.style.display = 'none';
		x4.style.display = 'none';
		x5.style.display = 'none';
	}
	else if (i == 3){
		b1.style.backgroundColor = "white";
		b2.style.backgroundColor = "white";
		b3.style.backgroundColor = "green";
		b4.style.backgroundColor = "white";
		b5.style.backgroundColor = "white";
		
		x1.style.display = 'none';
		x2.style.display = 'none';
		x3.style.display = 'block';
		x4.style.display = 'none';
		x5.style.display = 'none';
	}
	else if (i == 4){
		b1.style.backgroundColor = "white";
		b2.style.backgroundColor = "white";
		b3.style.backgroundColor = "white";
		b4.style.backgroundColor = "green";
		b5.style.backgroundColor = "white";
		
		x1.style.display = 'none';
		x2.style.display = 'none';
		x3.style.display = 'none';
		x4.style.display = 'block';
		x5.style.display = 'none';
	}
	else if (i == 5){
		b1.style.backgroundColor = "white";
		b2.style.backgroundColor = "white";
		b3.style.backgroundColor = "white";
		b4.style.backgroundColor = "white";
		b5.style.backgroundColor = "green";
		
		x1.style.display = 'none';
		x2.style.display = 'none';
		x3.style.display = 'none';
		x4.style.display = 'none';
		x5.style.display = 'block';
	}
}

function ShowForm(i){
	
	var x = document.getElementById("appForm");
	var y = document.getElementById("decForm");

	if (i == 1) {
		x.style.display == 'block';
		y.style.display == "none";
	}
	else if (i == 2) {
		x.style.display == "none";
		y.style.display == "block";
	}
}



