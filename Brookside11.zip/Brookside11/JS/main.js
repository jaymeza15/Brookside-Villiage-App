var taskContainer = document.getElementById("task-info");
//var btn = document.getElementById("btn");
var btn = document.getElementById("btn");

btn.addEventListener("click", function() {
	var ourRequest = new XMLHttpRequest();
	var url = "Load/loadtasks.php"
	ourRequest.open('GET', url);
	ourRequest.setRequestHeader("content-type" , "application/json");
	ourRequest.onload = function(){

		var ourData = JSON.parse(ourRequest.responseText);
		renderHTML(ourData);

	};

	ourRequest.send();
});

function renderHTML(data){
	var htmlString = "";
	
	taskContainer.innerHTML = "";

	var a = document.getElementById("I1").value;
	var b = document.getElementById("I2").value;
	var c = document.getElementById("I3").value;
	var d = document.getElementById("I4").value;
	var e = document.getElementById("tID").value;

	for(i = 0; i < data.length; i++){
		var x = data[i];
		
		if (b != " " && x.priority == b ) {
				htmlString += htmlString +
							  " TaskID: "    + x.taskID    + "<br>" +
							  " CreatorID: " + x.creatorID + "<br>" +
							  " Type: "      + x.type      + "<br>" +
							  " Priority: "  + x.priority  + "<br>" +
							  "<br>";
		}
	
	}
	taskContainer.innerHTML = htmlString;
	
}