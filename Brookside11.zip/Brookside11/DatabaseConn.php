<?php
$servername = "localhost";
$username = "root";
$password = "root";
$databasename = "BrooksideVillageDB";
$conn = mysqli_connect($servername, $username, $password, $databasename);
if(!$conn){
	die("Connection faileddue to the following error:".mysqli_connect_error());	
}

?>
