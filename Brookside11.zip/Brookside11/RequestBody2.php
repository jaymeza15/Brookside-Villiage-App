<center><h3 align="center"> Request Page </h3></center>
<div id="taskheader" align="center">
	<?php
		if(isset($_GET['success'])){
			if ($_GET['success'] == "approved") {
				echo '<p class="error"> Successfully approved the Request </p>';
			}
			else if ($_GET['success'] == "decline") {
				echo '<p class="error"> Successfully declined the Request </p>';
			}
		}
		if(isset($_GET['error'])){
			if ($_GET['error'] == "sqlerror") {
				echo '<p class="error"> Error: Please contact administrator </p>';
			}
			if ($_GET['error'] == "pending") {
				echo '<p class="error"> Error(Pending): Please contact administrator </p>';
			}
		}

	?>
	<table align="center"> 
		<tr> 
			<button onclick="Appear2(2)" id="B2" class="btn"> Pending 	   </button>
			<button onclick="Appear2(3)" id="B3" class="btn"> Approved	   </button>
			<button onclick="Appear2(4)" id="B4" class="btn"> Completed     </button>
			<button onclick="Appear2(5)" id="B5" class="btn"> Search        </button>
		</tr>
	</table>
</div>
<div id="createDiv" style="display: none;" align="center">
	
</div>

<div id="pDiv" style="display: none;">
	<h2> Pending Requests: </h2>
	<br>
	<?php
		require 'Display/pendingRequests.php';
	?>
</div>

<div id="aDiv" style="display: none;">
	<h2> Accepted Requests: </h2>
	<br>
	<?php
		require 'Display/approvedRequests.php';
	?>
</div>

<div id="cDiv" style="display: none;">
	<h2> Completed Requests: </h2>
	<br>
	<?php
		require 'Display/completedRequests.php';
	?>
</div>

<div id="sDiv" style="display: none;">
	<h2> Search Requests</h2>
	<br>
	<?php
		require 'Display/searchRequests.php';
	?>
</div>






