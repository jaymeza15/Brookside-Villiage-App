<?php
	require('DatabaseConn.php');
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Adding User </title>
		<link rel="stylesheet" type="text/css" href="CSS/template.css">
		<script type="text/javascript" src="JS/SelectOption.js"></script>
	</head>
	<body>
		<h1> <a href="Index.php"> Welcome to the Brookside Village Application </a> </h1>
		<br>
		<h2> Please enter info </h2>
		<br>
		<div class="enjoy-css">
			<?php
				if(isset($_GET['error']))
				{
					if ($_GET['error'] == "emptyfields") {
						echo '<p class="error"> One or More of the fields are empty </p>';
					}
					else if ($_GET['error'] == "permissions") {
						echo '<p class="error"> Wrong Permission Code</p>';	
					}
					else if ($_GET['error'] == "username") {
						echo '<p class="error"> The Username exists already</p>';	
					}
					else if ($_GET['error'] == "passwordconfirm") {
						echo '<p class="error"> Password does not match</p>';	
					}
					else if ($_GET['error'] == "passwordrequirements") {
						echo '<p class="error"> Password does not follow the requirements</p>';	
					}
					else if ($_GET['error'] == "room") {
						echo '<p class="error"> Room Taken</p>';	
					}
					else if ($_GET['error'] == "sqlerror") {
						echo '<p class="error"> There was an SQL error, Please contact the adminstrator </p>';
					}
				}
			?>

			<div id="usertype">
				What kind of User are you? <br>
				<select id="theSelect" onchange="UserType()"> 
					<option value=""> </option>
					<option value="Tenant">  Tenant  </option>
					<option value="Manager"> Manager </option>
					<option value="Board">   Board   </option>
				</select>
			</div>

			


			<form action="Action/UserAdd_Action.php" method="post">
				<input type="hidden"   name="usertype"   id="ut"> <br>
				<input type="number"   name="permission" id="per" placeholder="Permission Code" style="display: none;">
				<input type="text"     name="username"   placeholder="Username"  minlength="6"       maxlength="10">
				<input type="password" name="password"   placeholder="Password"  minlength="6"       maxlength="10">
				<div id="passReq"> Password needs 1 Uppercase, <br>1 Number, <br>atleast 6 characters</div>
				<input type="password" name="pass2"      placeholder="Confrim Password" maxlength="10">
				<input type="text"     name="firstname"  placeholder="First Name" >
				<input type="text"     name="lastname"   placeholder="Last Name"><br>
				<input type="date"     name="bday">
				<input type="text"     name="room"         placeholder="Room" id="rm"><br>
			    <input type="submit"   name="user-submit" value="Submit">
			</form>
		</div>


	</body>


</html>