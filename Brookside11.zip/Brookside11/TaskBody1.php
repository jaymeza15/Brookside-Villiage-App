<h3 align="center"> Tasks Page </h3>
<div id="taskheader" align="center">
	<?php
		if(isset($_GET['success'])){
			if ($_GET['success'] == "insert") {
				echo '<p class="error"> Successfully submitted the Task </p>';
			}
			else if ($_GET['success'] == "declined") {
				echo '<p class="error"> Successfully declined the Task </p>';
			}
			else if ($_GET['success'] == "completed") {
				echo '<p class="error"> Successfully completed the Task </p>';
			}
		}
		if(isset($_GET['error'])){
			if ($_GET['error'] == "sqlerror") {
				echo '<p class="error"> Error: Please contact administrator </p>';
			}
			else if ($_GET['error'] == "TooMany") {
				echo '<p class="error"> Error(Submittion): Enter way to many of certain type Complaint </p>';
			}
			else if ($_GET['error'] == "pending") {
				echo '<p class="error"> Error(Pending): Please contact administrator </p>';
			}
			else if ($_GET['error'] == "date") {
				echo '<p class="error"> Did not enter date for approval </p>';
			}
			else if ($_GET['error'] == "olddate") {
				echo '<p class="error"> Entered an invalid date </p>';
			}
		}

	?>
	<table align="center"> 
		<tr> 
			<button onclick="Appear(1)" id="B1" class="btn"> Create A Task </button>
			<button onclick="Appear(2)" id="B2" class="btn"> Pending 	   </button>
			<button onclick="Appear(3)" id="B3" class="btn"> Approved	   </button>
			<button onclick="Appear(4)" id="B4" class="btn"> Completed     </button>
			<button onclick="Appear(5)" id="B5" class="btn"> Search        </button>
		</tr>
	</table>
</div>
<div id="createDiv" style="display: none;" align="center">
	<br><br>
	Lets Create A Task
	<form action="Action/Task_Action.php" method="post">
		<br>
		<select class="select-css" name="type">
			<option> </option>
			<option value="Heating">     Heating     </option>
			<option value="Cooling">     Cooling     </option>
			<option value="Repair">      Repair      </option>
			<option value="Plumbing">    Plumbing    </option>
			<option value="Painting">    Painting    </option>
			<option value="Electric"> 	 Electric    </option>
			<option value="Locks">       Locks       </option>
			<option value="Replacement"> Replacement </option>
			<option value="Other">       Other       </option>
		</select>
		<br>
		<input type="text" name="subject" placeholder="Subject">
		<br><br>
		<input type="number" name="priority" placeholder="Priority">
		<br><br>
		<input type="text" name="description" placeholder="Description" style="height: 100px; width: 200px; align-content: left;">
		<br><br>
		<input type="submit" name="task-submit" value="Submit">
	</form>
</div>
<div id="pDiv" style="display: none;">
	<h2> Pending Tasks: </h2>
	<br>
	<?php
		//require 'Display/pendingTasks.php';
		require 'Display/pendingTasks.php';

	?>
</div>
<div id="aDiv" style="display: none;">
	<h2> Accepted Tasks: </h2>
	<br>
	<?php
		require 'Display/approvedTasks.php';
	?>
</div>
<div id="cDiv" style="display: none;">
	<h2> Completed Tasks: </h2>
	<br>
	<?php
		require 'Display/completedTasks.php';
	?>
</div>
<div id="sDiv" style="display: none;">
	<?php
		require 'Display/searchTasks.php';
	?>
</div>
