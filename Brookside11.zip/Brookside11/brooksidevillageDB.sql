-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 23, 2019 at 12:57 AM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `BrooksideVillageDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `complaintID` int(8) NOT NULL,
  `senderID` int(8) NOT NULL,
  `sender` varchar(21) NOT NULL,
  `type` varchar(15) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `status` int(1) NOT NULL,
  `submitDate` datetime NOT NULL,
  `compDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`complaintID`, `senderID`, `sender`, `type`, `subject`, `description`, `status`, `submitDate`, `compDate`) VALUES
(1, 12464785, 'Jason Meza', 'Tasks', 'Task problem', 'Taking way too long in dealing with tasks', 1, '2019-04-19 06:51:19', NULL),
(2, 12464785, 'Jason Meza', 'Heating', 'no Heat', 'no heat', 2, '2019-04-19 07:31:40', '2019-04-19'),
(3, 12464785, 'Jason Meza', 'Painting', 'Terrible Paint job', 'The previous task for paint job is terrible, I expect to be taken cared of', 2, '2019-04-19 07:45:20', '2019-04-17'),
(4, 23516631, 'Michael Saxer', 'Requests', 'Requests approval time', 'Taking forever to approve my request', 0, '2019-04-22 09:09:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(8) NOT NULL,
  `senderID` int(8) NOT NULL,
  `sender` varchar(21) NOT NULL,
  `targetID` int(8) NOT NULL,
  `target` varchar(21) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `statusRead` int(1) NOT NULL,
  `statusAction` int(1) NOT NULL,
  `submitDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `permissionUser` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permissionUser`) VALUES
(12345678),
(12345678);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `requestID` int(8) NOT NULL,
  `creatorID` int(8) NOT NULL,
  `fullName` varchar(21) NOT NULL,
  `priority` int(2) NOT NULL,
  `type` varchar(15) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `status` int(1) NOT NULL,
  `submitDate` datetime NOT NULL,
  `planDate` datetime DEFAULT NULL,
  `compDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`requestID`, `creatorID`, `fullName`, `priority`, `type`, `subject`, `description`, `status`, `submitDate`, `planDate`, `compDate`) VALUES
(1, 12464785, 'Jason Meza', 7, 'Flooring', 'New Floors', 'New need installition of floor tiles', 1, '2019-04-18 07:14:52', NULL, NULL),
(2, 16535937, 'Stephan Meerman', 2, 'Painting', 'Need new design', 'Would like to do some custom design painting done', 1, '2019-04-19 02:59:48', NULL, NULL),
(3, 16535937, 'Stephan Meerman', 4, 'Renovation', 'Space in dining room', 'would like to take down a wall to make more space', 0, '2019-04-19 03:00:21', NULL, NULL),
(4, 12464785, 'Jason Meza', 10, 'Appliance', 'New oven', 'Thanksgiving coming up and i need a new oven', 3, '2019-04-22 04:13:15', NULL, '2019-04-22 00:00:00'),
(5, 12464785, 'Jason Meza', 5, 'Electric', 'new tv', 'new tv needs new setup throughout the house', 2, '2019-04-22 04:13:53', NULL, '2019-04-22 00:00:00'),
(6, 12464785, 'Jason Meza', 5, 'Renovation', 'wall knocked down', 'another wall needed to kcok down', 0, '2019-04-22 05:27:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `taskID` int(8) NOT NULL,
  `creatorID` int(8) NOT NULL,
  `fullName` varchar(21) NOT NULL,
  `priority` int(2) NOT NULL,
  `type` varchar(15) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `status` int(1) NOT NULL,
  `submitDate` datetime NOT NULL,
  `planDate` date DEFAULT NULL,
  `compDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`taskID`, `creatorID`, `fullName`, `priority`, `type`, `subject`, `description`, `status`, `submitDate`, `planDate`, `compDate`) VALUES
(1, 12464785, 'Jason Meza', 5, 'Heating', 'no Heat', 'We Need Heat, we are freezing', 2, '2019-04-14 12:23:28', '2019-04-23', '2019-04-22'),
(2, 12464785, 'Jason Meza', 5, 'Cooling', 'AC isnt working', 'We burning', 0, '2019-04-14 03:26:38', NULL, NULL),
(3, 12464785, 'Jason Meza', 7, 'Repair', 'Window Broken', 'Window is broken and wind and bugs is coming inside', 2, '2019-04-14 04:03:39', '2019-04-23', '2019-04-19'),
(4, 12464785, 'Jason Meza', 8, 'Paint', 'kitchen', 'After fire, kitchen needs new paint job', 2, '2019-04-14 04:04:31', '2019-04-30', '2019-04-19'),
(5, 12464785, 'Jason Meza', 8, 'Locks', 'New Door Locks', 'Need new locks on my door', 1, '2019-04-14 04:08:57', '2019-04-30', NULL),
(6, 12464785, 'Jason Meza', 7, 'Electric', 'Outlets arent wokring', 'Some of the outlets are not suppling any electricity', 0, '2019-04-14 04:10:07', NULL, NULL),
(7, 12464785, 'Jason Meza', 9, 'Plumbing', 'Toilet', 'Problem in the bathroom. Toilet wont flush', 3, '2019-04-14 04:16:43', NULL, NULL),
(8, 16535937, 'Stephan Meerman', 10, 'Heating', 'Why no Heat?', 'I NEED MY HEAT!', 0, '2019-04-14 04:24:08', NULL, NULL),
(9, 16535937, 'Stephan Meerman', 10, 'Cooling', 'WHY NO AC?', 'I am creating a pool with my sweat', 3, '2019-04-14 04:24:40', NULL, NULL),
(10, 12464785, 'Jason Meza', 5, 'Replacement', 'door', 'new door', 0, '2019-04-22 02:06:29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(8) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `usertype` varchar(10) NOT NULL,
  `firstname` varchar(10) NOT NULL,
  `lastname` varchar(10) NOT NULL,
  `birthday` date NOT NULL,
  `room` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `usertype`, `firstname`, `lastname`, `birthday`, `room`) VALUES
(0, 'admin', 'admin', 'admin', 'admin', 'admin', '2019-01-01', '0'),
(0, 'admin', 'admin', 'admin', 'admin', 'admin', '2019-01-01', '0'),
(12464785, 'besttenant', 'pass', 'Tenant', 'Jason', 'Meza', '1993-04-15', '123'),
(16535937, 'SMeerman11', 'pass', 'Tenant', 'Stephan', 'Meerman', '2019-01-01', '124'),
(23516631, 'Manager100', 'pass', 'Manager', 'Michael', 'Saxer', '2019-01-01', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`complaintID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`requestID`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`taskID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `complaintID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `requestID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `taskID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;