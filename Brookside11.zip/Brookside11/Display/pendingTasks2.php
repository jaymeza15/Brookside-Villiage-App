<center><input type="text" id="myInput" onkeyup="searchFunction()" placeholder="Search for names.." title="Type in a name"></center>

<center>
<table id="myTable">
  <tr class="header">
    <th></th>
    <th style=""> Task ID     </th>
    <th style=""> Name        </th>
    <th style=""> Priority    </th>
    <th style=""> Subject     </th>
    <th style=""> Status      </th>
    <th style=""> Submit Date </th>
  </tr>
  
  <?php
    //Display Pending for Tenants
    if ($idnum[0] == 1) {
      $sql = "SELECT * FROM tasks WHERE creatorID = '$idnum' AND status = 0 ";
    }
    else{
      $sql = "SELECT * FROM tasks WHERE status = 0 ";
    }
  
    $result = mysqli_query($conn, $sql);
  
    if (mysqli_num_rows($result) > 0) {
      /*echo "<center><table class = 'table1'>
            <tr>
              <td> </td>
              <td> Task ID</td>
              <td> Name </td>
              <td> Priority</td>
              <td> Subject</td>
              <td> Status</td>
              <td> SubmitDate</td>
            </tr>";*/
      while ($row = mysqli_fetch_assoc($result)) {    
          echo "<tr>
              <td> 
                <form action = 'Tasks_Form.php' method = 'post' >
                  <input type = 'hidden' name = 'tID' value = " .$row["taskID"] . ">
                  <input type = 'submit' name = 'view-submit' value = 'View' >
                </form>
              </td>
              <td> " . $row["taskID"]     . "</td>
              <td> " . $row["fullName"]   . "</td>
              <td> " . $row["priority"]   . "</td>
              <td> " . $row["subject"]    . "</td>
              <td>      Pending            </td>
              <td> " . $row["submitDate"] . "</td>
             </tr>
          ";
      }
      echo "</table></center>";
      
    }
    else{
      if($idnum[0] == 1){
        echo "<center><p>There are no are current Pending Task for " . $_SESSION["first"] . " " . $_SESSION["last"] . "</p><br>";
      }
      else{
        echo "<center><p>There are no are current Pending Task </p><br>";
      }
    }
  ?>

</table>
