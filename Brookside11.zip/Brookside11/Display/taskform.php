<?php
	if (isset($_POST["view-submit"])) {

		$theID = $_SESSION["ID"];
		$tID = $_POST["tID"];

		$sql = "SELECT * FROM tasks WHERE taskID = '$tID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count != 1){
			header("Location: ../Tasks_View?error=sqlerror");
			exit();
		}


		while ($row = mysqli_fetch_assoc($result)) {
			
			echo " <center><h4> Task Description </h4></center>
				   
				   <center><table class = 'displayTable'>
						<tr> <td>Task ID</td>     <td>" . $row["taskID"]. " </td> </tr>
						<tr> <td>Creator ID</td>  <td>" . $row["creatorID"]. " </td> </tr>
						<tr> <td>Name</td>        <td>" . $row["fullName"]. " </td> </tr>
						<tr> <td>Priority</td>    <td>" . $row["priority"]. " </td> </tr>
						<tr> <td>Subject</td>     <td>" . $row["subject"]. " </td> </tr>
						<tr> <td>Description</td> <td>" . $row["description"]. " </td> </tr>";
					
					if($row["status"] == 0){
						echo "<tr> <td>Status</td>      <td> Pending </td> </tr>";
					}
					else if($row["status"] == 1){
						echo "<tr> <td>Status</td>      <td> Approved </td> </tr>";
					}

					echo"<tr> <td>Submit Date</td> <td>" . $row["submitDate"]. " </td> </tr>
				   </table></center>
				   <br>";

				   echo "<div id = 'actionDiv'>";
				if($row["status"] == 0){
					//Pending tasks only
					if ($theID[0] == 1) {
						//if its a Tenant and Pending Tasks
					}
					else{
						//Else it is a Manager/Board therefore can approve(with date) or decline
						echo "<center>
								<div id='appForm' >
										<form method='post'>
										Please enter date for approval, if not decline: <br>
										<input type='hidden' name='tID' value = '$tID'>
										<input type='date' name='planDate'> <br> <br>
										<button type='submit' name='app-sub' class='btn' formaction='Action/TaskUpdate_Action.php'> Submit Approval</button>
										<button type='submit' name='dec-sub' class='btn' formaction='Action/TaskUpdate_Action.php'> Decline</button>
									</form>
								</div>
							</center>";
					}

					
				}
				else if($row["status"] == 1){
					//Approved tasks only
					if ($theID[0] == 1) {
						//if its a tenant and approved
						echo "<center>
									<form action = 'Complaints_View.php' method = 'post'>
										<input type = 'hidden' name = 'tID' value = '$tID'>
										<button type = 'submit' class = 'btn'> Complaint </button>
									</form>
							  </center>";
						
					}
					else{
						//if its a manager or board and its approved
						echo "<center>
								<form method = 'post' >
									<input type = 'hidden' name = 'tID' value = '$tID' >
									<button type = 'submit' name = 'comp-sub' class = 'btn' formaction = 'Action/TaskUpdate_Action.php'> Submit Completion </button>
								</form>
							</center>";
					}
				}
					echo "</div>";
		}
	}
	else{
		header("Location: ../Tasks_View.php?error=taskview");
		exit();
	}
?>