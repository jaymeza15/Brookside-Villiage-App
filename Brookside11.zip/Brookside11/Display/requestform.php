<?php
	if (isset($_POST["view-submit"])) {
		$tID = $_POST["tID"];

		$sql = "SELECT * FROM requests WHERE requestID = '$tID' ";
		$result = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($result);

		if($count != 1){
			header("Location: ../Requests_View?error=sqlerror");
			exit();
		}


		while ($row = mysqli_fetch_assoc($result)) {
			
			echo " <center><h4> Request Description </h4></center>
				   
				   <center><table class = 'displayTable'>
						<tr> <td>Request ID</td>  <td>" . $row["requestID"]. " </td> </tr>
						<tr> <td>Creator ID</td>  <td>" . $row["creatorID"]. " </td> </tr>
						<tr> <td>Name</td>        <td>" . $row["fullName"]. " </td> </tr>
						<tr> <td>Priority</td>    <td>" . $row["priority"]. " </td> </tr>
						<tr> <td>Subject</td>     <td>" . $row["subject"]. " </td> </tr>
						<tr> <td>Description</td> <td>" . $row["description"]. " </td> </tr>";
					
					if($row["status"] == 0){
						echo "<tr> <td>Status</td>      <td> Pending </td> </tr>";
					}
					else if($row["status"] == 1){
						echo "<tr> <td>Status</td>      <td> Approved </td> </tr>";
					}

					echo"<tr> <td>Submit Date</td> <td>" . $row["submitDate"]. " </td> </tr>
				   </table></center>
				   <br>";

				   echo "<div id = 'actionDiv'>";
				if($row["status"] == 0){
					if ($idnum[0] != 1) {
						
						echo "<center>
							<div id='appForm' >
								<form method='post'>
									<input type='hidden' name='tID' value = '$tID'>
									<button type='submit' name='app-sub' class='btn' formaction='Action/RequestUpdate_Action.php'> Submit Approval</button>
									<button type='submit' name='dec-sub' class='btn' formaction='Action/RequestUpdate_Action.php'> Decline </button>
								</form>
							</div>
							</center>";
					}

					
				}
				else if($row["status"] == 1){
					if ($idnum[0] == 1) {
						echo "<center>
								<form method = 'post' >
									<input type = 'hidden' name = 'tID' value = '$tID' >
									<button type = 'submit' name = 'comp-sub' class = 'btn' formaction = 'Action/RequestUpdate_Action.php'> Submit Completion </button>
								</form>
							</center>";
						}
				}
				echo "</div>";
		}
	}
	else{
		header("Location: ../Tasks_View.php?error=taskview");
		exit();
	}
?>