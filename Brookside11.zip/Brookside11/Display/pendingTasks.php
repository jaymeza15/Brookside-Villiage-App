<?php
	if(isset($_POST["task-search"])){

	}
	else{

		//Display Pending for Tenants
		if ($idnum[0] == 1) {
			$sql = "SELECT * FROM tasks WHERE creatorID = '$idnum' AND status = 0 ";
		}
		else{
			$sql = "SELECT * FROM tasks WHERE status = 0 ";
		}
	
		$result = mysqli_query($conn, $sql);
	
		if (mysqli_num_rows($result) > 0) {
			echo "<center><table class = 'table1'>
						<tr>
							<th> </th>
							<th> Task ID</th>
							<th> Name </th>
							<th> Priority</th>
							<th> Subject</th>
							<th> Status</th>
							<th> SubmitDate</th>
						</tr>";
			while ($row = mysqli_fetch_assoc($result)) {		
					echo "<tr>
							<td> 
								<form action = 'Tasks_Form.php' method = 'post' >
									<input type = 'hidden' name = 'tID' value = " .$row["taskID"] . "style = 'font-size:10px;'>
									<input type = 'submit' name = 'view-submit' value = 'View' >
								</form>
							</td>
							<td> " . $row["taskID"]     . "</td>
							<td> " . $row["fullName"]   . "</td>
							<td> " . $row["priority"]   . "</td>
							<td> " . $row["subject"]    . "</td>
							<td>     	Pending            </td>
							<td> " . $row["submitDate"] . "</td>
					 	 </tr>
					";
			}
			echo "</table></center>";
			
		}
		else{
			if($idnum[0] == 1){
				echo "<center><p>There are no are current Pending Task for " . $_SESSION["first"] . " " . $_SESSION["last"] . "</p><br>";
			}
			else{
				echo "<center><p>There are no are current Pending Task </p><br>";
			}
		}
	
	}
?>