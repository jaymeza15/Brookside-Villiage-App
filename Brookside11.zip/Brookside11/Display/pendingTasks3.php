<div class="form-group pull-right">
    <input type="text" class="search form-control" placeholder="What you looking for?">
</div>
<table class="table table-striped" id="userTbl">
    <thead>
    <tr>
      <th>Firstname</th>
      <th>Lastname</th>
      <th>Email</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>John</td>
        <td>Moe</td>
        <td>john@moe.com</td>
    </tr>
    <tr>
        <td>Mary</td>
        <td>Doe</td>
        <td>mary@doe.com</td>
    </tr>
    <tr>
        <td>July</td>
        <td>Rest</td>
        <td>july@gmail.com</td>
    </tr>
    </tbody>
</table>