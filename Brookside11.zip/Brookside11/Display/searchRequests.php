<br>
<br>
<center>
	<form >
		Request ID  &nbsp; <input type="text"   id="I1" name="tID"> <br><br>
		Priority &nbsp; <input type="number" id="I2" name="pri"> <br><br>
		Type     &nbsp; <input type="text"   id="I3" name="type"> <br><br>
		Status   &nbsp; <input type="number" id="I4" name="stat"> <br><br>
		<?php //echo "    <input type='hidden' id='tID' value='$idnum'";?>
	</form>

	<button id="btn"> Button </button>

	<div id="request-info"></div>

	<script src="JS/Request_main.js"></script>
</center>