<?php  
	echo "<h1> Hello " . $_SESSION['first'] . " " . $_SESSION['last'] . "</h1>";	

?>
