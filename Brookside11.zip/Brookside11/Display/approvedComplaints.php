<?php
//Display Pending for Tenants
		if ($idnum[0] == 1) {
			$sql = "SELECT * FROM complaints WHERE senderID = '$idnum' AND status = 1 ";
		}
		else{
			$sql = "SELECT * FROM complaints WHERE status = 1 ";
		}
	
		$result = mysqli_query($conn, $sql);
	
		if (mysqli_num_rows($result) > 0) {
			echo "<center><table class = 'displayTable'>
						<tr>
							<th> </th>
							<th> Complaint ID</th>
							<th> Sender </th>
							<th> Type</th>
							<th> Subject</th>
							<th> Status</th>
							<th> SubmitDate</th>
						</tr>";
			while ($row = mysqli_fetch_assoc($result)) {		
					echo "<tr>
							<td> 
								<form action = 'Complaints_Form.php' method = 'post' >
									<input type = 'hidden' name = 'tID' value = " .$row["complaintID"] . ">
									<input type = 'submit' name = 'view-submit' value = 'View' >
								</form>
							</td>
							<td> " . $row["complaintID"]     . "</td>
							<td> " . $row["sender"]   . "</td>
							<td> " . $row["type"]   . "</td>
							<td> " . $row["subject"]    . "</td>
							<td>     	Under Review           </td>
							<td> " . $row["submitDate"] . "</td>
					 	 </tr>
					";
			}
			echo "</table></center>";
			
		}
		else{
			if($idnum[0] == 1){
				echo "<center><p>There are no are current Under Review Complaint for " . $_SESSION["first"] . " " . $_SESSION["last"] . "</p><br>";
			}
			else{
				echo "<center><p>There are no are current Under Review Complaint </p><br>";
			}
		}
?>