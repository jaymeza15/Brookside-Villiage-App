<?php
	//Display Pending for Tenants
	if ($idnum[0] == 1) {
		$sql = "SELECT * FROM requests WHERE creatorID = '$idnum' AND status = 0 ";
	}
	else{
		$sql = "SELECT * FROM requests WHERE status = 0 ";
	}
	
	$result = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($result) > 0) {
			echo "<center>
				    <table class = 'table1'>
						<tr>
							<th> </th>
							<th> RequestID</th>
							<th> Name </th>
							<th> Priority</th>
							<th> Type </th>
							<th> Status</th>
							<th> SubmitDate</th>
						</tr>";
			while ($row = mysqli_fetch_assoc($result)) {
				
					echo "<tr>
							<td> 
								<form action = 'Requests_Form.php' method = 'post' >
									<input type = 'hidden' name = 'tID' value = " .$row["requestID"] . ">
									<input type = 'submit' name = 'view-submit' value = 'View' >
								</form>
							</td>
							<td> " . $row["requestID"]     . "</td>
							<td> " . $row["fullName"]   . "</td>
							<td> " . $row["priority"]   . "</td>
							<td> " . $row["type"]    . "</td>
							<td>     	Pending            </td>
							<td> " . $row["submitDate"] . "</td>
					 	 </tr>
					";
			}
			echo "</table></center>";
			
	}
	else{
		if($idnum[0] == 1){
			echo "<center><p>There are no are current Pending Requests for " . $_SESSION["first"] . " " . $_SESSION["last"] . "</p><br>";
		}
		else{
			echo "<center><p>There are no are current Pending Requests </p><br>";
		}
	}
?>