<br>
<br>
<center>
	<form >
		Complaint ID  &nbsp; <input type="text"   id="I1" name="tID"> <br><br>
		Type          &nbsp; <input type="text"   id="I2" name="pri"> <br><br>
		Priority      &nbsp; <input type="number" id="I3" name="pri"> <br><br>
		Status        &nbsp; <input type="number" id="I4" name="stat"> <br><br>
		<?php //echo "    <input type='hidden' id='tID' value='$idnum'";?>
	</form>

	<button id="btn"> Button </button>

	<div id="complaint-info"></div>

	<script src="JS/Complaint_main.js"></script>
</center>