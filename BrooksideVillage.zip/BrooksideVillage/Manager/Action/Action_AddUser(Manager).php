<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['pass']); 
      $mypassword2 = mysqli_real_escape_string($db,$_POST['pass2']);
	  
      $sql = "SELECT id FROM usertable WHERE username = '$myusername' and password = '$mypassword' and userType = 'Manager' ";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) { $error = "Your Login Name or Password is taken";}
      else{
		if($mypassword == $mypassword2)
		{
			$sql1 = "INSERT INTO usertable (username, password, userType) 
                    VALUES ('$myusername' , '$mypassword' , 'Manager')";
		}
		else
		{
			echo "Confirm doesnt match";
		}
		
      	if(!mysqli_query($db, $sql1)){echo "Not inserted";}
      	else{header("Location: ../View_CreateManager.php");}
      }
   }
?>
<!--
<div>
				<form>
					<input type="text" name="firstname" placeholder="First Name">
					<input type="text" name="lastname" placeholder="Last Name">
					<input type="date" name="bday">
				</form>
</div>
-->