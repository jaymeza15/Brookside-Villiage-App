<?php

if(isset($_POST['logout-submit'])){
	
session_start();
session_unset();
session_destroy();
header("Location: ../UserSelection.php");
}
else{
	
	header("Location: View_Home(Tenant).php");
}

?>