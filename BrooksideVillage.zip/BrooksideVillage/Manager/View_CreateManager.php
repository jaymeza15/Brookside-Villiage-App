<!DOCTYPE html>
<html>
	<head>
		<title> Adding Tenant </title>
		<link rel="stylesheet" href="../CSS/template1.css">
		<link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
	</head>
	
	<body>
		<H1> Welcome to the Brookside Villiage Application</H1>
		<p> </p>
		<H2> Please enter info </H2>
		
			<form action ="Action/Action_CreateManager.php" method = "post">
				<input type = "text" name = "first" placeholder = "First Name" size="35">
				<input type = "text" name = "last" placeholder = "Last Name">
				<input type = "date"  name = "bday">
				<center><button type = "submit" name = "Submit"> Submit </button>
			</form>	
	
	</body>
	
</html>