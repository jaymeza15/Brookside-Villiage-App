<?php
	include("config.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
		<link rel="stylesheet" type="text/css" href="../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<a href="View_Home(Manager)"><h1><i>Brookside Village</i></h1></a>
		<center>
		<font size="6">
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="View_Home(Manager).php">                   Home</a></td>
					<td><a href="Tasks/View_Tasks(Manager).php">            View Task(s)</a></td>
					<td><a href="Requests/View_Requests(Manager).php">      View Request(s)</a></td> 
					<td><a href="Complaints/View_Complaints(Manager).php">  View Complaint(s)</a></td>
					<td><a href="Vehicles/View_Vehicles(Manager).php">       View Vehicle(s)</a></td>
					<td><a href="Fines/View_Fines(Manager).php">            View Fine(s)</a></td>
					<td><a href="Messages/View_Messages(Manager).php">       View Message(s)</a></td>
				</tr>
			</table>
		</font>
		
		<form  action ="Logout(Manager).php" method = "post">
				<button class="circ" type = "submit" name = "logout-submit"> Logout </button>
		</form>
		
		<font size="6">
			<table class "table1" style="width:80%", frame="box", align=left>
				<?php
					$sql1 = "SELECT * FROM tasktable WHERE 1";
					$sql2 = "SELECT * FROM requesttable WHERE 1";
					$sql3 = "SELECT * FROM complainttable WHERE 1";
					$sql4 = "SELECT * FROM vehicletable WHERE 1";
					$sql5 = "SELECT * FROM finetable WHERE 1";
					$sql6 = "SELECT * FROM messagetable WHERE 1";
					$result1 = mysqli_query($db,$sql1); 
					$result2 = mysqli_query($db,$sql2);
					$result3 = mysqli_query($db,$sql3);
					$result4 = mysqli_query($db,$sql4);
					$result5 = mysqli_query($db,$sql5);
					$result6 = mysqli_query($db,$sql6);
					$count1 = mysqli_num_rows($result1);
					$count2 = mysqli_num_rows($result2);
					$count3 = mysqli_num_rows($result3);
					$count4 = mysqli_num_rows($result4);
					$count5 = mysqli_num_rows($result5);
					$count6 = mysqli_num_rows($result6);
					
					echo "<tr><td>Tasks: </td><td> ";
						 printf("%d",$count1);
					echo "<tr><td>Requests: </td><td>";
						 printf("%d",$count2);
					echo "<tr><td>Complaints: </td><td>";
						 printf("%d",$count3);
					echo "<tr><td>Vehicles: </td><td>";
						 printf("%d",$count4);
					echo "<tr><td>Fines: </td><td>";
						 printf("%d",$count5);
					echo "<tr><td>Messages: </td><td>";
						 printf("%d",$count6);
					echo "</td></tr>";
	
				?>
			</table>
		</font>
		
		</header>
	</body>
</html>