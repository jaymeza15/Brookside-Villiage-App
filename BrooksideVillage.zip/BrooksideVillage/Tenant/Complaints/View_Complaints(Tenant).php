<?php
	include("config.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Task View</title>
		<link rel="stylesheet" type="text/css" href="../../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<a href="../View_Home(Tenant).php"><h1><i>Brookside Village</i></h1><a>
		<center>
		<font size="6">
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="../View_Home(Tenant).php">Home</a></td>
					<td><a href="View_AddComplaints(Tenant).php">Create Complaint</a></td>
					<td><a href="View_DeleteComplaints(Tenant).php">Delete Complaint</a></td>
				</tr>
			</table>
			<table>	
				<tr>
					<th>ID</th>
					<th>SenderID</th>
					<th>Sender</th>
					<th>RecieverID</th>
					<th>Reciever</th>
					<th>Subject</th>
					<th>Description</th>
					<th>Submit Date</th>
				</tr>
			<?php
				
				$sql = "SELECT complaintID, senderID, sender, recieverID, reciever, subject, Description, SubmitDate FROM complainttable";
				$result = mysqli_query($db, $sql);

				if (mysqli_num_rows($result) > 0) {
				// output data of each row
					while($row = mysqli_fetch_assoc($result)) {
						echo "<tr><td>" . $row["complaintID"] . "</td><td>" 
										. $row["senderID"] . "</td><td>" 
									    . $row["sender"] . "</td><td>" 
										. $row["recieverID"] . "</td><td>" 
										. $row["reciever"] . "</td><td>" 
										. $row["subject"] . "</td><td>"
										. $row["Description"] . "</td><td>" 
										. $row["SubmitDate"] . "</td><tr>";
					}
				} 
				else {
					echo "0 results";
				}
				
			?>
			</table>
			
		</font>
		
		
		</header>
	</body>
</html>