<?php
	include("config.php");
	session_start();
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {
      // id and task name sent from the form
	  $cid = mysqli_real_escape_string($db,$_POST['cID']);  
	  $rid = mysqli_real_escape_string($db,$_POST['rID']); 
      $sub = mysqli_real_escape_string($db,$_POST['sub']);
	
	  $sql = "SELECT complaintID FROM complainttable 
				WHERE complaintID = '$cid' AND recieverID = '$rid' AND subject = '$sub' ";
	  //$sql1 = "INSERT INTO tasktable (Name, Description, Priority, SubmitDate) 
                              //VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
      $result = mysqli_query($db,$sql);
	  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
	  
	  $count = mysqli_num_rows($result);
	  
	  if($count == 1){
		  
		//$sqll = "DELETE FROM tasktable WHERE taskID = '".$myid."' and Name = '".$myname."' " ;
		
		$sql2 = "DELETE FROM complainttable WHERE complaintID = '$cid' " ;
		
		if(!empty($sql))
		{
			if(!mysqli_query($db,$sql2))
			{
				echo "Not Deleted";
			}
			else
			{
				header("Location: View_DeleteComplaints(Tenant).php");
			}
		}
		else
		{
			echo "Empty String";
		}
	  }
	  
	  else{
		  echo "Task doesnt exist";
		  $error = "Task doesnt exist";
	  }
		
	}
	
	
?>