<?php
	include("config.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Adding Complaint</title>
		<link rel="stylesheet" type="text/css" href="../../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<a href="../View_Home(Tenant).php"><h1><i>Brookside Village</i></h1><a>
		<center>
		<font size="6">
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="../View_Home(Tenant).php">Home</a></td>					
					<td><a href="View_Complaints(Tenant).php">View Complaints</a></td>
					<td><a href="View_DeleteComplaints(Tenant).php">Delete A Complaints</a></td>
				</tr>
			</table>
		
			<form action="Action_AddComplaints.php" method="post">
					RecieverID: 
					<input type="number" name="rID"><br>
					Name To: 
					<input type="text" name="rName"><br>
					Subject: 
					<input type="text" name="sub"><br>
					Description: 
					<input type="text" name="des"><br>
					
					<br>
					<input type="submit" value="Submit">
			</form>
		</font>
		
		
		</header>
	</body>
</html>