<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myfname = mysqli_real_escape_string($db,$_POST['first']);
      $mylname = mysqli_real_escape_string($db,$_POST['last']); 
      $mybday = mysqli_real_escape_string($db,$_POST['bday']);
	  
      $sql = "SELECT tenantID FROM tenanttable WHERE Firstname = '$myfname' and Lastname = '$mylname' and Birthday = '$mybday'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) 
	  { 
		$error = "Your information matches are record, you already have an account";
	  }
	  
      else{
		
			//$sql1 = "INSERT INTO usertable (username, password) 
                    //VALUES ('$myusername' , '$mypassword')";
			
			$sql2 = "INSERT INTO tenanttable (Firstname, Lastname, Birthday) 
                    VALUES ('$myfname' , '$mylname' , '$mybday')";
					
      	if(!mysqli_query($db, $sql2))
		{
			echo "Not inserted";
		}
      	else
		{
			header("Location: ../Login(Tenant).php");
		}
      }
   }
?>