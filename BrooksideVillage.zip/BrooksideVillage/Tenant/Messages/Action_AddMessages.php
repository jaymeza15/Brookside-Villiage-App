<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $rID = mysqli_real_escape_string($db,$_POST['rID']);
	  $rSub = mysqli_real_escape_string($db,$_POST['sub']);
      $sDes = mysqli_real_escape_string($db,$_POST['des']); 
	  $date = date("Y-m-d");

      
      $sql = "SELECT id FROM messagetable WHERE id = '$rID' and Subject = '$rSub'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) { $error = "Your Request is already submitted";}
      else{

      	$sql1 = "INSERT INTO messagetable (SenderID, RecieverID, Subject, Description, SubmitDate) 
                                   VALUES ('1' , '$rID' , '$rSub' , '$sDes' , '$date' )";
		  
		//$sql1 = "INSERT INTO tasktable (Name, Description, Priority, SubmitDate) 
          //                 VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
      
	    //$sql1 = "INSERT INTO tasktable (taskID, Name, Description, Priority) 
                    //VALUES ('01' , '$myname' , '$mydes' , '$myprior' )";
	  
      	if(!mysqli_query($db, $sql1)){echo "Not inserted";}
      	else{header("Location: View_Messages(Tenant).php");}
      }
   }
?>