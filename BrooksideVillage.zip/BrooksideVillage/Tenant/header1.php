<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
		<link rel="stylesheet" type="text/css" href="CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
		<h1><i>Brookside Village</i></h1>
		<center>
		<font size="6">
		<table class="table1" style="width:80%", frame="box", align=right>
			<tr>
				<td><a href="Home.php">Home</a></td>
				<td><a href="ViewTasks.php">View Tasks</a></td>
				<td><a href="url">View Requests</a></td> 
				<td><a href="url">Submit Request/Complaint</a></td>
				<td><a href="Vehicle.php">Vehicle Registration</a></td>
				<td><a href="url">Pay Fine(s)</a></td>
				<td><a href="url">Message User</a></td>
			</tr>
		</table>
		</font>
		<form  action ="php files/logout.action.php" method = "post">
				<button class="circ" type = "submit" name = "logout-submit"> Logout </button>
		</form>
		
		</header>
	</body>
</html>