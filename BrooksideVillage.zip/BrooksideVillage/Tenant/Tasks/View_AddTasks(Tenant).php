<?php
	include("config.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Adding Task</title>
		<link rel="stylesheet" type="text/css" href="../../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<a href="../View_Home(Tenant).php"><h1><i>Brookside Village</i></h1><a>
		<center>
		<font size="6">
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="../View_Home(Tenant).php">Home</a></td>					
					<td><a href="View_Tasks(Tenant).php">View Tasks</a></td>
					<td><a href="View_DeleteTasks(Tenant).php">Delete A Task</a></td>
				</tr>
			</table>
		
			<form action="Action_AddTasks.php" method="post">
					Name: 
					<input type="text" name="name"><br>
					Description: 
					<input type="text" name="description"><br>
					Priority: 
					<input type="text" name="priority"><br>
					<br>
					<input type="submit" value="Submit">
			</form>
		</font>
		
		
		</header>
	</body>
</html>