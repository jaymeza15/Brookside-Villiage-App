<?php
	include("config.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Adding Complaint</title>
		<link rel="stylesheet" type="text/css" href="../../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<a href="../View_Home(Tenant).php"><h1><i>Brookside Village</i></h1><a>
		<center>
		<font size="6">
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="../View_Home(Tenant).php">         Home</a></td>					
					<td><a href="View_Vehicles(Tenant).php">        View Vehicle</a></td>
					<td><a href="View_DeleteVehicles(Tenant).php">  Delete Vehicle</a></td>
				</tr>
			</table>
		
			<form action="Action_AddVehicles.php" method="post">
					Make: 
					<input type="text" name="make"><br>
					Model: 
					<input type="text" name="model"><br>
					Licence: 
					<input type="text" name="licence"><br>

					<br>
					<input type="submit" value="Submit">
			</form>
		</font>
		
		
		</header>
	</body>
</html>