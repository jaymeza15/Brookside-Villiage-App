<?php
	include("config.php");
	session_start();
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {
      // id and task name sent from the form
	  $myid = mysqli_real_escape_string($db,$_POST['id']);  
      $mylicence = mysqli_real_escape_string($db,$_POST['licence']);
	
	  $sql = "SELECT carID FROM vehicleTable 
				WHERE carID = '$myid' AND Licence = '$mylicence' ";
	  //$sql1 = "INSERT INTO tasktable (Name, Description, Priority, SubmitDate) 
                              //VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
      $result = mysqli_query($db,$sql);
	  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
	  
	  $count = mysqli_num_rows($result);
	  
	  if($count == 1){
		  
		//$sqll = "DELETE FROM tasktable WHERE taskID = '".$myid."' and Name = '".$myname."' " ;
		
		$sql2 = "DELETE FROM vehicletable WHERE carID = '$myid' " ;
		
		if(!empty($sql))
		{
			if(!mysqli_query($db,$sql2))
			{
				echo "Not Deleted";
			}
			else
			{
				header("Location: View_DeleteVehicles(Tenant).php");
			}
		}
		else
		{
			echo "Empty String";
		}
	  }
	  
	  else{
		  echo "Task doesnt exist";
		  $error = "Task doesnt exist";
	  }
		
	}
	
	
?>