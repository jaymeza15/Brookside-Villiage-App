<?php
	include("config.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Adding Fine</title>
		<link rel="stylesheet" type="text/css" href="../../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<a href="../View_Home(Tenant).php"><h1><i>Brookside Village</i></h1><a>
		<center>
		<font size="6">
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="../View_Home(Tenant).php">        Home</a></td>					
					<td><a href="View_Fines(Tenant).php">       View Fines</a></td>
					<td><a href="View_DeleteFines(Tenant).php"> Delete A Fine</a></td>
				</tr>
			</table>
		
			<form action="Action_AddFines.php" method="post">
					Fee: 
					<input type="number" name="fee"><br>
					Description: 
					<input type="text" name="des"><br>
					
					
					<br>
					<input type="submit" value="Submit">
			</form>
		</font>
		
		
		</header>
	</body>
</html>