<?php
	include("config.php");
	session_start();
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {
      // id and task name sent from the form
	  $fid = mysqli_real_escape_string($db,$_POST['fID']);
	  $fee = mysqli_real_escape_string($db,$_POST['fee']);  
	  $des = mysqli_real_escape_string($db,$_POST['des']); 
	
	  $sql = "SELECT fineID FROM finetable 
				WHERE fineID = '$fid' AND Fee = '$fee' AND Description = '$des' ";
	  //$sql1 = "INSERT INTO tasktable (Name, Description, Priority, SubmitDate) 
                              //VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
      $result = mysqli_query($db,$sql);
	  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
	  
	  $count = mysqli_num_rows($result);
	  
	  if($count == 1){
		  
		//$sqll = "DELETE FROM tasktable WHERE taskID = '".$myid."' and Name = '".$myname."' " ;
		
		$sql2 = "DELETE FROM finetable WHERE fineID = '$fid' " ;
		
		if(!empty($sql))
		{
			if(!mysqli_query($db,$sql2))
			{
				echo "Not Deleted";
			}
			else
			{
				header("Location: View_DeleteFines(Tenant).php");
			}
		}
		else
		{
			echo "Empty String";
		}
	  }
	  
	  else{
		  echo "Task doesnt exist";
		  $error = "Task doesnt exist";
	  }
		
	}
	
	
?>