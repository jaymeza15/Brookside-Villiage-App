<?php
	include("config.php");
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Deleting Fine</title>
		<link rel="stylesheet" type="text/css" href="../../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	
	<body>
		<header>
			<a href="../View_Home(Tenant).php"><h1><i>Brookside Village</i></h1><a>
		<center>
		<font size="6">
			<!--    Header tabs:  -->
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="../View_Home(Tenant).php">     Home</a></td>
					<td><a href="View_Fines(Tenant).php">    View Fine</a></td>
					<td><a href="View_AddFines(Tenant).php"> Add Fine</a></td>
				</tr>
			</table>
			
			<h3> Enter the fine you want to delete</h3>
			<br>
			<form action="Action_DeleteFines.php" method="post">
				Fee ID: <input type="Number" name="fID"> &nbsp;
				Fee: <input type="Number" name="fee"> &nbsp;
				Description:  <input type="text"   name="des"> <br>
				<input type="submit" name="Delete">
				<br><br>
			</form>
			<table>	
				<tr>
					<th>Fine ID</th>
					<th>Fee</th>
					<th>Description</th>
					<th>Submit Date</th>
				</tr>
			<?php
				
				$sql = "SELECT fineID, Fee, Description, SubmitDate FROM finetable";
				$result = mysqli_query($db, $sql);

				if (mysqli_num_rows($result) > 0) {
				// output data of each row
					while($row = mysqli_fetch_assoc($result)) {
						echo "<tr><td>" . $row["fineID"] . "</td><td>" 
										. $row["Fee"] . "</td><td>" 
									    . $row["Description"] . "</td><td>" 
										. $row["SubmitDate"] . "</td><tr>";
					}
				} 
				else {
					echo "0 results";
				}
				
			?>
			</table>
			
			
			
		</font>
		
		
		</header>
	</body>
</html>