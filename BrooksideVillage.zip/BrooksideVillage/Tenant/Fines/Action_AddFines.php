<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $fee = mysqli_real_escape_string($db,$_POST['fee']);
	  $des = mysqli_real_escape_string($db,$_POST['des']);
	  $date = date("Y-m-d");

      
      $sql = "SELECT fineID FROM finetable WHERE fineID = '$fee' and Description = '$des'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) { $error = "Your fine is already submitted";}
      else{

      	$sql1 = "INSERT INTO finetable (Fee, Description, SubmitDate) 
                              VALUES ( '$fee' , '$des' , '$date' )";
		  
		//$sql1 = "INSERT INTO tasktable (Name, Description, Priority, SubmitDate) 
          //                 VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
      
	    //$sql1 = "INSERT INTO tasktable (taskID, Name, Description, Priority) 
                    //VALUES ('01' , '$myname' , '$mydes' , '$myprior' )";
	  
      	if(!mysqli_query($db, $sql1)){echo "Not inserted";}
      	else{header("Location: View_Fines(Tenant).php");}
      }
   }
?>