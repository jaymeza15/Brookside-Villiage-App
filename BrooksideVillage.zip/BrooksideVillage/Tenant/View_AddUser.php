<!DOCTYPE html>
<html>
	<head>
		<title> Adding User </title>
		<link rel="stylesheet" href="../CSS/template1.css">
		<link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
	</head>
	
	<body>
		<H1> Welcome to the Brookside Villiage Application</H1>
		<p> </p>
		<H2> Please enter info </H2>
		
			<form action ="Action/Action_AddUser.php" method = "post">
				<input type = "text" name = "username" placeholder = "Username" size="35">
				<input type = "password" name = "pass" placeholder = "Password">
				<input type = "password"  name = "pass2" placeholder = "ConfirmPassword">
				<center><button type = "submit" name = "login-submit"> Submit </button>
			</form>	
	
	</body>
	
</html>