<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
		<link rel="stylesheet" type="text/css" href="../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
		<a href="View_Home(Tenant).php"><h1><i>Brookside Village</i></h1></a>
		<center>
		<font size="6">
		<table class="table1" style="width:80%", frame="box", align=right>
			<tr>
				<td><a href="View_Home(Tenant).php">                  Home</a></td>
				<td><a href="Tasks/View_Tasks(Tenant).php">           View Tasks</a></td>
				<td><a href="Requests/View_Requests(Tenant).php">     View Requests</a></td> 
				<td><a href="Complaints/View_Complaints(Tenant).php"> View Complaints</a></td>
				<td><a href="Vehicles/View_Vehicles(Tenant).php">     Vehicle Registrations</a></td>
				<td><a href="Fines/View_Fines(Tenant).php">           Fine(s)</a></td>
				<td><a href="Messages/View_Messages(Tenant).php">     Messages</a></td>
			</tr>
		</table>
		</font>
		<form  action ="Logout.php" method = "post">
				<button class="circ" type = "submit" name = "logout-submit"> Logout </button>
		</form>
		
		</header>
	</body>
</html>