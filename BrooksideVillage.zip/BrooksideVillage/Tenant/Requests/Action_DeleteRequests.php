<?php
	include("config.php");
	session_start();
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {
      // id and task name sent from the form
	  $myid = mysqli_real_escape_string($db,$_POST['id']);  
      $myname = mysqli_real_escape_string($db,$_POST['name']);
	
	  $sql = "SELECT requestID FROM requestTable 
				WHERE requestID = '$myid' AND Name = '$myname' ";
	  //$sql1 = "INSERT INTO tasktable (Name, Description, Priority, SubmitDate) 
                              //VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
      $result = mysqli_query($db,$sql);
	  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
	  
	  $count = mysqli_num_rows($result);
	  
	  if($count == 1){
		  
		//$sqll = "DELETE FROM tasktable WHERE taskID = '".$myid."' and Name = '".$myname."' " ;
		
		$sql2 = "DELETE FROM requesttable WHERE requestID = '$myid' " ;
		
		if(!empty($sql))
		{
			if(!mysqli_query($db,$sql2))
			{
				echo "Not Deleted";
			}
			else
			{
				header("Location: View_DeleteRequests(Tenant).php");
			}
		}
		else
		{
			echo "Empty String";
		}
	  }
	  
	  else{
		  echo "Task doesnt exist";
		  $error = "Task doesnt exist";
	  }
		
	}
	
	
?>