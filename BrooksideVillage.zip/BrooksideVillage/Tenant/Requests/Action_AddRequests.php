<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myname = mysqli_real_escape_string($db,$_POST['name']);
      $mydes = mysqli_real_escape_string($db,$_POST['description']); 
	  $myprior = mysqli_real_escape_string($db,$_POST['priority']);
	  $date = date("Y-m-d");

      
      $sql = "SELECT requestID FROM requesttable WHERE Name = '$myname' and Priority = '$myprior'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) { $error = "Your Request is already submitted";}
      else{

      	$sql1 = "INSERT INTO requesttable (Name, Description, Priority, SubmitDate) 
                              VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
		  
		//$sql1 = "INSERT INTO tasktable (Name, Description, Priority, SubmitDate) 
          //                 VALUES ('$myname' , '$mydes' , '$myprior' , '$date' )";
      
	    //$sql1 = "INSERT INTO tasktable (taskID, Name, Description, Priority) 
                    //VALUES ('01' , '$myname' , '$mydes' , '$myprior' )";
	  
      	if(!mysqli_query($db, $sql1)){echo "Not inserted";}
      	else{header("Location: View_Requests(Tenant).php");}
      }
   }
?>
