<?php
	include("config.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Adding Request</title>
		<link rel="stylesheet" type="text/css" href="../../CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<a href="../View_Home(Tenant).php"><h1><i>Brookside Village</i></h1><a>
		<center>
		<font size="6">
			<table class="table1" style="width:80%", frame="box", align=right>
				<tr>
					<td><a href="../View_Home(Tenant).php">Home</a></td>					
					<td><a href="View_Requests(Tenant).php">View Request</a></td>
					<td><a href="View_DeleteRequests(Tenant).php">Delete A Request</a></td>
				</tr>
			</table>
		
			<form action="Action_AddRequests.php" method="post">
					Name: 
					<input type="text" name="name"><br>
					Description: 
					<input type="text" name="description"><br>
					Priority: 
					<input type="text" name="priority"><br>
					<br>
					<input type="submit" value="Submit">
			</form>
		</font>
		
		
		</header>
	</body>
</html>