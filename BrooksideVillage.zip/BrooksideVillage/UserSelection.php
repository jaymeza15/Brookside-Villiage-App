<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
		<link rel="stylesheet" type="text/css" href="CSS/TheBestCss4.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<h1><i>Brookside Village</i></h1>
		<center>
		<font size="6">
		<table class="table1" style="width:80%", frame="box", align=right>
			<tr><td><a href="Tenant/Login(Tenant).php">   Tenant</a></td></tr>
			<tr><td><a href="Manager/Login(Manager).php"> Manager</a></td></tr>
			<tr><td><a href="Board/Login(Board).php">     Board</a></td></tr>
		</table>
		</font>
		</header>
	</body>
</html>